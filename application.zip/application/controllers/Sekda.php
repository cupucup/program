<?php
class Sekda extends CI_Controller{
    
    function __construct(){
        
        parent::__construct();
        $this->load->model('m_tulisan');
        $this->load->model('m_galeri');
        $this->load->model('m_pengumuman');
        $this->load->model('m_agenda');
        $this->load->model('m_kontakkami');
        $this->load->model('m_files');
        $this->load->model('m_pengunjung');
        $this->m_pengunjung->count_visitor();
        
    }
    
    function index(){
            $this->data['kontakkami']=$this->m_kontakkami->get_kontakkami_home();
        
            // $this->data['main_view']   = 'depan/v_beranda';
            $this->data['berita']=$this->m_tulisan->get_berita_home();
            $this->data['title']  = 'Sekertaris Daerah';
            $this->data['main_view']   = 'depan/v_sekda';
            $this->load->view('theme/template',$this->data);
    }

}