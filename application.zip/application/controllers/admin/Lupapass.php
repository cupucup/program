<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Lupapass extends CI_Controller
{
    function __construct(){
        parent::__construct();
        $this->load->model('m_akun');
        
    }
    public function index()
    {

        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');

        if ($this->form_validation->run() == FALSE) {
            $data['title'] = 'Halaman Reset Password | Tutorial reset password CodeIgniter @ https://recodeku.blogspot.com';
            $this->load->view('admin/v_lupapass', $data);
        } else {
            $email = $this->input->post('email');
            $clean = $this->security->xss_clean($email);
            $userInfo = $this->m_akun->getUserInfoByEmail($clean);

            if (!$userInfo) {
                $this->session->set_flashdata('sukses', 'email address salah, silakan coba lagi.');
                redirect(site_url('admin/login'), 'refresh');
            }

            //build token   

            $token = $this->m_akun->insertToken($userInfo->pengguna_id);
            $qstring = $this->base64url_encode($token);
            $url = site_url() . 'admin/lupapass/reset_password/token/' . $qstring;
            $link = '<a href="' . $url . '">' . $url . '</a>';

            $message = '';
            $message .= '<strong>Hai, anda menerima email ini karena ada permintaan untuk memperbaharui  
                 password anda.</strong><br>';
            $message .= '<strong>Silakan klik link ini:</strong> ' . $link;

            echo $message; //send this through mail  
            exit;
        }
    }

    public function reset_password()
    {
        $token = $this->base64url_decode($this->uri->segment(4));
        $cleanToken = $this->security->xss_clean($token);

        $tbl_pengguna = $this->m_akun->isTokenValid($cleanToken); //either false or array();          

        if (!$tbl_pengguna) {
            $this->session->set_flashdata('sukses', 'Token tidak valid atau kadaluarsa');
            redirect(site_url('admin/login'), 'refresh');
        }

        $data = array(
            'title' => 'Halaman Reset Password',
            'nama' => $tbl_pengguna->pengguna_nama,
            'email' => $tbl_pengguna->pengguna_email,
            'token' => $this->base64url_encode($token)
        );

        $this->form_validation->set_rules('pengguna_password', 'Password', 'required|min_length[5]');
        $this->form_validation->set_rules('passconf', 'Password Confirmation', 'required|matches[password]');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('admin/v_resetpass', $data);
        } else {

            $post = $this->input->post(NULL, TRUE);
            $cleanPost = $this->security->xss_clean($post);
            $hashed = md5($cleanPost['pengguna_password']);
            $cleanPost['pengguna_password'] = $hashed;
            $cleanPost['pengguna_id'] = $tbl_pengguna->pengguna_id;
            unset($cleanPost['passconf']);
            if (!$this->m_akun->updatePassword($cleanPost)) {
                $this->session->set_flashdata('sukses', 'Update password gagal.');
            } else {
                $this->session->set_flashdata('sukses', 'Password anda sudah  
             diperbaharui. Silakan login.');
            }
            redirect(site_url('admin/login'), 'refresh');
        }
    }

    public function base64url_encode($data)
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    public function base64url_decode($data)
    {
        return base64_decode(str_pad(strtr($data, '-_', '+/'), strlen($data) % 4, '=', STR_PAD_RIGHT));
    }
}