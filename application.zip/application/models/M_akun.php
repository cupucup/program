<?php
defined('BASEPATH') or exit('No direct script access allowed');
class M_akun extends CI_Model
{

    function daftar($data)
    {
        $this->db->insert('tbl_pengguna', $data);
    }

    //Start: method tambahan untuk reset code  
    public function getUserInfo($id)
    {
        $q = $this->db->get_where('tbl_pengguna', array('pengguna_id' => $id), 1);
        if ($this->db->affected_rows() > 0) {
            $row = $q->row();
            return $row;
        } else {
            error_log('no user found getUserInfo(' . $id . ')');
            return false;
        }
    }

    public function getUserInfoByEmail($email)
    {
        $q = $this->db->get_where('tbl_pengguna', array('pengguna_email' => $email), 1);
        if ($this->db->affected_rows() > 0) {
            $row = $q->row();
            return $row;
        }
    }

    public function insertToken($pengguna_id)
    {
        $token = substr(sha1(rand()), 0, 30);
        $date = date('Y-m-d');

        $string = array(
            'token' => $token,
            'pengguna_id' => $pengguna_id,
            'created' => $date
        );
        $query = $this->db->insert_string('tokens', $string);
        $this->db->query($query);
        return $token . $pengguna_id;
    }

    public function isTokenValid($token)
    {
        $tkn = substr($token, 0, 30);
        $uid = substr($token, 30);

        $q = $this->db->get_where('tokens', array(
            'tokens.token' => $tkn,
            'tokens.pengguna_id' => $uid
        ), 1);

        if ($this->db->affected_rows() > 0) {
            $row = $q->row();

            $created = $row->created;
            $createdTS = strtotime($created);
            $today = date('Y-m-d');
            $todayTS = strtotime($today);

            if ($createdTS != $todayTS) {
                return false;
            }

            $tbl_pengguna = $this->getUserInfo($row->pengguna_id);
            return $tbl_pengguna;
        } else {
            return false;
        }
    }

    public function updatePassword($post)
    {
        $this->db->where('pengguna_id', $post['pengguna_id']);
        $this->db->update('tbl_pengguna', array('pengguna_password' => $post['pengguna_password']));
        return true;
    }
    //End: method tambahan untuk reset code  
}