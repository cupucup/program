<div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy;<script>document.write(new Date().getFullYear());</script> Halmahera Timur Administrator System 
            </span>
          </div>
        </div>