 <div class="header-top_area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="header_top_wrap d-flex justify-content-between align-items-center">
                                <div class="text_wrap"><?php foreach ($kontakkami->result() as $row) : ?>
                                    <p><span><?php echo $row->kontakkami_hp;?></span> | <span>Email : <?php echo $row->kontakkami_email;?></span></p><?php endforeach;?>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        