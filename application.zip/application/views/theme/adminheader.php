
            <div class="header-top_area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="header_top_wrap d-flex justify-content-between align-items-center">
                                <div class="text_wrap">
                                    <p><span>Call : </span> | <span>Email : </span></p>
                                </div>
                                <div class="text_wrap">
                                    <p><a href="#"> <i class="ti-user"></i>  Login</a> <a href="#">Register</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        