<br><br><br><div class="event_details_area ">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="single_event d-flex align-items-center">
                        <div class="thumb">
                        
                    
                        <div class="event_details_info">
                            <div class="event_info">
                                <h2 style=" font-weight: bold; text-align: center;">POTENSI ZONA PARIWISATA
<br>
KAB HALMAHERA TIMUR</h2>
                                
                            </div>
                          
                     <br>
<p style="text-align:justify;"><h3 style=" font-weight: bold;">1.   Sub Zona Wisata Alam Pantai/Pesisir dan Pulau-Pulau Kecil</h3><p style="text-align:justify;">
Arahan pengembangan sub zona wisata alam pantai/pesisir dan pulau-pulau kecil di Kabupaten Halmahera Timur meliputi : kawasan Tewil dan kawasan Wailukum;
<h3 style=" font-weight: bold;">2.  Sub Zona Wisata Alam Bawah Laut</h3><p style="text-align:justify;">
Kegiatan pariwisata ini terutama bertumpu pada kegiatan yang berkaitan dengan rekreasi dan pariwisata yang memanfaatkan potensi sumberdaya alam dan ekosistemnya baik di kawasan pesisir maupun pulau-pulau kecil seperti menyelam (diving) dan snorkeling.<br><p style="text-align:justify;">
Arahan pengembangan sub zona wisata alam bawah laut menyelam(diving) di Kabupaten Halmahera Timur meliputi: Pulau Oto, Pulau To, Tanjung Nakau, Pulau Lewi, Pulau Plum, Pulau Sloton, Teluk Buli, diKabupaten Halmahera Timur. Arahan pengembangan sub zona wisata alam bawah laut (snorkeling) di Kabupaten Halmahera Timur meliputi: Pulau Foli, pantai Dodaga, Tanjung Patlean, Tanjung Sipub,Tanjung Gyeklolemdi, Pulau Woi, di Kabupaten Halmahera Timur.
<h3 style=" font-weight: bold;">3.  Sub Zona Wisata Olahraga Air</h3><p style="text-align:justify;">
Sub zona wisata olahraga air yang dimaksud adalah jet ski, dan mancing. Arahan pengembangan sub zona wisata olahraga air di Kabupaten Halmahera Timur meliputi: Tanjung Gorango,Tanjung Lieli, Teluk Wayaubo, Tanjung Dorosagu, Tanjung Wayamli, Pulau Sloton, Teluk Buli.
<br>
Sumber : RPJMD Kab Halmahera Timur 2021 - 2025

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>