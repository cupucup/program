 
<?php foreach ($data->result() as $row) : ?>
<br>
<!doctype html>
 <html>
 <head>
 <title><?php echo $row->pegawai_jabatan;?></title>
</head>
 <body>
   <div class="row justify-content-center">
                <div class="col-lg-8 col-md-10">
                    <div class="section_title text-center mb-70">
                        <h3 class="mb-45"><?php echo $row->pegawai_jabatan;?></h3>
                        
                    </div>
                </div>
            </div>
 <form action="#" style="width: 1000px;padding-left: 100px;"class="posisi";>
 <fieldset class="h"/>
 <table style="width: 980px;">
 <tr>
 <td rowspan="15" width="250px">
 <img src="<?php echo base_url().'assets/images/'.$row->guru_photo;?>" width="250px" height="420px"/>
 </td>
 </tr>
 &nbsp;
 <tr>
    <td>Nama</td>
    <td>:</td>
    <td><?php echo $row->guru_nama;?></td>
  </tr>
   
  <tr>
    <td>Jabatan</td>
        <td>:</td>

    <td><?php echo $row->pegawai_jabatan;?></td>
  </tr>
  <tr>
    <td>Tempat Lahir</td>
        <td>:</td>

    <td><?php echo $row->guru_tmp_lahir;?></td>
  </tr>
  <tr>
    <td>Tanggal Lahir</td>
        <td>:</td>

    <td><?php echo $row->guru_tgl_lahir;?></td>
  </tr>
  <tr>
    <td>Jenis Kelamin</td>
        <td>:</td>

    <td><?php echo $row->guru_jenkel;?></td>
  </tr>
 
 </table>
 </fieldset>
 </form>
 <br>
 </body>
 </html><?php endforeach;?>