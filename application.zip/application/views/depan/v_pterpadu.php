<br><br><br><div class="event_details_area ">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="single_event d-flex align-items-center">
                        <div class="thumb">
                        
                    
                        <div class="event_details_info">
                            <div class="event_info">
                                <h2 style=" font-weight: bold; text-align: center;">POTENSI KAWASAN TERPADU
<br>
KAB HALMAHERA TIMUR</h2>
                                
                            </div>
                           
                     <br>
<p style="text-align:justify;">
Pemerintah Daerah Kabupaten Halmahera Timur saat ini, merencanakan
pengembangkan 11 (sebelas) Kawasan Terpadu Baru untuk mendukung kegiatan
Sektor Pertanian, Perkebunan, Perikanan dan Kawasan Perkotaan untuk
mengoptimalkan potensi ekonomi.
<p>
    1.  Adanya Rencana Pembangunan Kawasan Transmigrasi Kota Maba<br>
2.  Rencana Pengembangan Kawasan Perdesaan Sondo-Sondo Sebagai Kawasan Perkebunan Terpadu<br>
3.  Rencana Pengembangan Kawasan Perikanan Terpadu Tanjung Roni dan Saramaake di Kecamatan Wasile Selatan<br>
4.  Rencana Pengembangan Kawasan Perikanan Terpadu Sill di Kecamatan Maba Selatan<br>
5.  Rencana Pengembangan Kawasan Perikanan Terpadu Dabo dan Kawasan Pariwisata Jara-Jara<br>
6.  Rencana Pengembangan Kawasan Fayaul-Bukutio Sebagai Kawasan Perkotaan Baru<br>
7.  Rencana Pengembangan Kawasan Sekitar Bandara Buli Sebagai Kawasan Perkotaan Baru<br>
8.  Rencana Pengembangan Kawasan Perkotaan Maba<br>
9.  Rencana Pengembangan Kawasan Perkotaan Wayamli<br>
10. Rencana Pengembangan Kawasan Perkotaan Lolobata<br>
11. Adanya Penetapan Kawasan Smelter di Buli<br><br>
sumber : RPJMD Kab Halmahera Timur 2021 - 2025
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>