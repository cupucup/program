
<div class="recent_event_area ">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8 col-md-10">
                    <div class="section_title text-center mb-70">
                        <h3 class="mb-45">SEKERTARIS DAERAH</h3>
                        
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-10">
                     <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="team-item">
                            <div class="team-img" height="250px">
                                <img src="style/img/experts/sekda.jpg">
                            </div>
                           
                        </div>
                    </div>
                       
                    
                </div>
              <table>
  <tr>
    <th>Nama</th>
    <th>Ricky Chairul Richfat, ST.,MT</th>
  </tr>
  <tr>
    <td>Tempat/Tgl Lahir</td>
    <td>Jakarta, 13 Februari 1979</td>
  </tr>
  <tr>
    <td>Istri</td>
    <td>-</td>
  </tr>
  <tr>
    <td>Anak</td>
    <td>-</td>
  </tr>
  
  <tr>
    <td>Pendidikan Formal</td>
    <td>•   SD Kenari Tinggi 2 Ternate 1990</td>
  </tr>
  <tr>
    <td></td>
    <td>•   SMP Negeri 1 Ternate 1993</td>
  </tr>
  <tr>
    <td></td>
    <td>•   SMA Negeri 1 Ternate 1996</td>
  </tr>
  <tr>
    <td></td>
    <td>•   S1 Universitas Samratulangi Manado 2004</td>
  </tr>
  <tr>
    <td></td>
    <td>•   S2 Universitas Gadja Mada 2008</td>
  </tr>
  <tr>
    <td>Riwayat Pekerjaan</td>
    <td>•   Kepala Seksi Tata  Kota Bappeda Kab. Halmahera Timur 2008</td>
  </tr>
  <tr>
    <td></td>
    <td>•   Kepala Bidang Fisik Sarana dan Prasarana Bappeda Kab. Halmahera Timur 2010</td>
  </tr>
  <tr>
    <td></td>
    <td>•   Sekretaris Bappeda Kab. Halmahera Timur 2011</td>
  </tr>
  <tr>
    <td></td>
    <td>•   Kepala Bappeda Kab. Halmahera Timur 2014</td>
  </tr>
  <tr>
    <td></td>
    <td>•   Kepala BP4D Kab. Halmahera Timur 2017</td>
  </tr>
  <tr>
    <td></td>
    <td>•   Sekretaris Daerah Kabupaten Halmahera Timur 2021- sekarang</td>
  </tr>
  <tr>
    <td>Riwayat Organisasi</td>
    <td>•   Ketua KONI Kab. Halmahera Timur 2022- sekarang</td>
  </tr>
</table>
    </div>
            </div>
        </div>
    </div>
    <br>