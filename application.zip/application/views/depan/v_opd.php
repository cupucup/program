<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<!-- Global site tag (gtag.js) - Google Analytics -->
<script type="text/javascript" async="" src="https://www.google-analytics.com/analytics.js"></script>
<script async="" src="https://www.google-analytics.com/analytics.js"></script>
<script type="text/javascript" async="" src="https://www.google-analytics.com/analytics.js"></script>
<script async="" src="https://www.google-analytics.com/analytics.js"></script>
<script async="" src="https://www.googletagmanager.com/gtag/js?id=UA-154801838-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-154801838-1');
</script>
	<title>Portal Resmi Pemerintah Kabupaten Halmahera Timur</title>
	<link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('');?>style/img/haltimmm.png">
	<meta name="description" content="Portal Resmi Pemerintah Kabupaten Halmahera Timur">
	<meta name="keywords" content="Kabupaten Halmahera Timur, pemerintah Kabupaten Halmahera Timur, portal pemerintah Kabupaten Halmahera Timur">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" content="Alfiar Wiguna">
	<link rel="stylesheet" href="<?php echo base_url('style/css/style.css')?>"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('');?>style/css/style_landing_page.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="style/css/search.css">
	
    <!-- CSS here -->
    <link rel="stylesheet" href="<?php echo base_url('');?>style/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url('');?>style/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo base_url('');?>style/css/magnific-popup.css">
    <link rel="stylesheet" href="<?php echo base_url('');?>style/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo base_url('');?>style/css/themify-icons.css">
    <link rel="stylesheet" href="<?php echo base_url('');?>style/css/nice-select.css">
    <link rel="stylesheet" href="<?php echo base_url('');?>style/css/flaticon.css">
    <link rel="stylesheet" href="<?php echo base_url('');?>style/css/gijgo.css">
    <link rel="stylesheet" href="<?php echo base_url('');?>style/css/animate.css">
    <link rel="stylesheet" href="<?php echo base_url('');?>style/css/slicknav.css">
    <link rel="stylesheet" href="<?php echo base_url('');?>style/css/style.css">
    <link rel="stylesheet" href="<?php echo base_url('');?>style/css/table.scss">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="<?php echo base_url().'theme/css/dataTables.bootstrap4.min.css'?>" rel="stylesheet">
    <!-- Google Web Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat&family=Oswald:wght@400;500;600&display=swap" rel="stylesheet"> 

        <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap" rel="stylesheet">
        
      <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Montserrat:300,400,500,700" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<script type="text/javascript">
      (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-85280822-1', 'auto');
  ga('send', 'pageview');
</script></head>
<style>
body {
  background-image: url('style/img/background/bgg.jpeg');
  background-color: rgba(0,0,0,0.658);
  background-blend-mode:overlay;
  background-size: cover;
   background-position: center center;
    background-repeat: no-repeat;
     background-attachment: fixed;
  
}
</style>



	<!-- <body style="background-image: url('c.jpeg'); overflow: auto; background-size: 100%; max-width: auto; max-height: auto; background-repeat: no-repeat;"> -->
	<!-- <body class="bg-layer"> -->
	<body>
<!--Logo-->
<div class="header-top_area" style="background: #A6C3C5;">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="header_top_wrap d-flex justify-content-between align-items-center">
                                
                                    <div class="d-flex justify-content-start mt-4">
                                    	<a class="btn btn-outline-light rounded-circle text-center mr-2 px-0" style="width: 38px; height: 38px;" href="#"><i class="fab fa-instagram"></i></a>
                                    	<a class="btn btn-outline-light rounded-circle text-center mr-2 px-0" style="width: 38px; height: 38px;" href="#"><i class="fab fa-facebook-f"></i></a>
                                    	<a class="btn btn-outline-light rounded-circle text-center mr-2 px-0" style="width: 38px; height: 38px;" href="https://www.youtube.com/channel/UC_iKSQgAVWqnYZ06vvcJneA"><i class="fab fa-youtube"></i></a>
                    <a class="btn btn-outline-light rounded-circle text-center mr-2 px-0" style="width: 38px; height: 38px;" href="https://twitter.com/haltimkab"><i class="fab fa-twitter"></i></a>
                    
                    
                </div>
                                <div class="text_wrap"><p></p></div><div class="text_wrap"><p></p></div><div class="text_wrap"><p></p></div><div class="text_wrap"><p></p></div><div class="text_wrap"><p></p></div><div class="text_wrap"><p></p></div>
                                <div class="text_wrap" id="eml" style="color: white; padding-left: -0%;"><a href="mailto:haltim@haltimkab.go.id"><i class="fa fa-envelope"></i>&nbsp;<span>Email : haltim@haltimkab.go.id</span></a></div>

                                <div class="text_wrap">
                                    <p><form action="<?php echo site_url('blog/search');?>" method="get">
                                <div class="form-group">
                                    <div class="input-group mb-3">
                                        <input type="text" name="keyword" class="form-control" placeholder='Search '
                                            onfocus="this.placeholder = ''"
                                            onblur="this.placeholder = 'Search'" autocomplete="off" required>
                                        <div class="input-group-append">
                                            <button class="btn" type="submit"><i class="ti-search"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <div class="modal fade" id="ModalSearch" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" style="z-index: 10000;">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-body">  
                <form action="<?php echo site_url('blog/search');?>" method="GET">
                    <div class="input-group">
                      <input type="text" name="search_query" class="form-control input-search" style="height: 40px;" placeholder="Cari..." required>
                      <span class="input-group-btn">
                        <button class="btn btn-default" type="submit" style="height: 40px;background-color: #ccc;"><span class="fa fa-search"></span></button>
                      </span>
                    </div>
                </form>
              </div>
            </div>
          </div>
        </div></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        
            <div class="header-top_area" style="background: #ffff;">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="header_top_wrap d-flex justify-content-between align-items-center">
                                
                                    <div class="d-flex justify-content-start mt-4">
                                    	<div class="logo">
                                        <a href="<?php echo base_url('');?>">
                                            <img src="<?php echo base_url('');?>style/img/halmah.png" alt="" height="80px" width="100%">
                                        </a>

                                    </div>

                    
                </div>
                                <div class="text_wrap"><p><h5>Pemerintah Kabupaten Halmahera Timur</h5>
                            <p>Jl. Pusat Pemerintahan, Kecamatan Kota Maba.<br> Halmahera Timur, Prov. Maluku Utara, 97862</p></div><div class="text_wrap"><p></p></div><div class="text_wrap"><p></p></div><div class="text_wrap"><p></p></div><div class="text_wrap"><p></p></div><div class="text_wrap"><p></p></div>
                                <div class="text_wrap" id="eml" style="color: white; padding-left: -0%;"></div>

                                <div class="text_wrap text-center">
                                    <h2>Limabot Fayfiye</h2>
                                    <h3>Mewujudkan Halmahera Timur yang Maju dan Sejahtera</h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
 <div class="flex" style="background: #A6C3C5;">
    <div class="flex_content flex2" style=" padding-left: 3%; padding-top: 2%; padding-bottom: 3%;">
        <h2>BADAN </h2>
        <ul>
            <a href=""target="_blank"><li>Badan Perencanaan Pembangunan, Penelitian dan Pengembangan Daerah</li></a>
            <a href=""target="_blank"><li>Badan Kepegawaian dan Pengembangan Sumber Daya Aparatur </li></a>
            <a href=""target="_blank"><li>Badan Pengelola Keuangan dan Aset Daerah</li></a>
            <a href=""target="_blank"><li>Badan Kesatuan Kebangsaan dan Politik</li></a>
            <a href=""target="_blank"><li>Badan Penanggulangan Bencana Daerah</li></a>
        </ul>
        <h2>BAGIAN</h2>
        <ul>
            <a href=""target="_blank"><li>Bagian Pemerintahan</li></a>
            <a href=""target="_blank"><li>Bagian Kesejahteraan Rakyat</li></a>
            <a href=""target="_blank"><li>Bagian Hukum dan Organisasi </li></a>
            <a href=""target="_blank"><li>Bagian Perekonomian dan Sumber Daya Alam </li></a>
            <a href=""target="_blank"><li>Bagian Administrasi Pembangunan </li></a>
            <a href=""target="_blank"><li>Bagian Pengadaan Barang dan Jasa</li></a>
            <a href=""target="_blank"><li>Bagian IJmum dan Protokol</li></a>
            <a href=""target="_blank"><li>Bagian Kearsipan dan Perpustakaan</li></a>
            <a href=""target="_blank"><li>Bagian Komunikasi dan Dokumentasi Pimpinan</li></a>
        </ul></a>
        <h2>INSTANSI LAINNYA</h2>
        <ul>
            <a href=""><li>Inspektorat</li></a>
            <a href=""><li>Rumah Sakit LJmum Daerah Maba</li></a>
            <a href=""><li>Sekretariat DPRD</li></a>
            
        </ul>
    </div>
    
    <div class="flex_content" style=" padding-left: 35%; padding-top: 2%;">
        <h2>DINAS</h2>
        <ul>
            <a href="https://disdikhaltim.rahadian-consulting.com/"><li>Dinas Pendidikan</li></a>
            <a href="https://dinkeshaltim.rahadian-consulting.com/"><li>Dinas Kesehatan</li></a>
            <a href="https://puprhaltim.rahadian-consulting.com/"><li>Dinas Pekerjaan Umum dan Penataan Ruang</li></a>
            <a href="https://perumahanhaltim.rahadian-consulting.com/"><li>Dinas Perumahan dan Kawasan Permukiman</li></a>
            <a href="https://pertanianhaltim.rahadian-consulting.com/"><li>Dinas Pertanian</li></a>
            <a href="https://panganhaltim.rahadian-consulting.com/"><li>Dinas Ketahanan Pangan</li></a>
            <a href="https://perikananhaltim.rahadian-consulting.com/"><li>Dinas Kelautan dan Perikanan</li></a>
            <a href=""><li>Dinas Pariwisata dan Kebudayaan</li></a>
            <a href=""><li>Dinas Satuan Polisi Pamong Praja</li></a>
            <a href=""><li>Dinas Transmigrasi dan Tenaga Kerja</li></a>
            <a href=""><li>Dinas Perdagangan, Perindustrian, Koperasi, dan LJKM</li></a>
            <a href="https://dishubhaltim.rahadian-consulting.com/"><li>Dinas Perhubungan</li></a>
            <a href=""><li>Dinas Sosial</li></a>
            <a href=""><li>Dinas Pemberdayaan Masyarakat dan Desa </li></a>
            <a href="https://dpmptsphaltim.rahadian-consulting.com/"><li>Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu </li></a>
            <a href=""><li>Dinas Pengendalian Penduduk, Keluarga Berencana, Pemberdayaan Perempuan dan Perlindungan Anak </li></a>
            <a href="https://kominfohaltim.rahadian-consulting.com/"><li>Dinas Komunikasi, Informatika, Persandian dan Statistik </li></a>
            <a href=""><li>Dinas Pertanahan dan Lingkungan Hidup </li></a>
            <a href="https://disdukcapilhaltim.rahadian-consulting.com/"><li>Dinas Kependudukan dan Pencatatan Sipil</li></a>
            <a href=""><li>Dinas Kepemudaan dan Olahraga</li></a>
        </ul>
        
    </div>
</div>
