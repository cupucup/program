<br><br><br><div class="event_details_area ">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="single_event d-flex align-items-center">
                        <div class="thumb">
                        
                    
                        <div class="event_details_info">
                            <div class="event_info">
                                <h2 style=" font-weight: bold; text-align: center;">POTENSI ZONA PERIKANAN TANGKAP
<br>
KAB HALMAHERA TIMUR</h2>
                                
                            </div>
                          
                     <br>
<p style="text-align:justify;"><h3 style=" font-weight: bold;">1.   Sub Zona Perikanan Pelagis Di perairan Halmahera Timur</h3>
<p style="text-align:justify;">Pelagis adalah ikan yang hidup dipermukaan sampai kolom perairan laut. Arahan pemanfaatan sub zona perikanan pelagis meliputi:<br>
Perairan Maba-Teluk Buli, Perairan Patani-Laut Halmahera, Perairan Teluk Buli-Laut Halmahera, Perairan Halmahera Timur-Laut Halmahera, Perairan Teluk Kao-Teluk Wasile, Perairan Teluk Kao-Halmahera Timur-Laut Halmahera.
<h3 style=" font-weight: bold;">2.  Sub Zona Perikanan Demersal Di perairan Halmahera Timur</h3>
<p style="text-align:justify;">Demersal adalah ikan yang hidup dan makan di dasar laut. Arahan pemanfaatan sub zona perikanan demersal meliputi: 
Perairan Pulai Seal-Maba Selatan, Perairan Pulau Cef- Maba Selatan, Perairan Pulau
Inggelan-Maba Selatan, Perairan Gotowasi- Teluk Wailo-Maba Selatan, Perairan Teluk Buli, Perairan Pulau Pakal- Maba, Perairan Lolasita-Maba Utara, Perairan Tanjung Lili-Teluk Lolasita- Maba Utara, Perairan Dorosagu-Maba Utara, Perairan Subaim-Tanjung
Guruo-Wasile, Perairan Teluk Wasile, Perairan Hatetabako-Kakaraeno- Wasile Tengah, Perairan Tanjung Gorango-Teluk Dobo-Maba Utara
<h3 style=" font-weight: bold;">3.  Sub Zona Perikanan Pelagis dan Demersal Di perairan Halmahera Timur</h3>
<p style="text-align:justify;">Perairan Maba-Buli- Teluk Buli-Halmahera Timur, Perairan Teluk Buli, Perairan Wayamli- Bebsili-Tanjung Bus-Bus-Maba Tengah, Perairan Miaf-Sosolat-Dorosagu- Wasileo-Maba Utara, Perairan Patlean-Teluk Dono-Jara-jara-Maba Utara, Perairan Labi-labi-Tatam-Marimoi-Bololo-Tanjung Nakau-Wasile Utara, Perairan Hilaitetor-Teluk IfisTanjung Tutuo-Wasile Utara, Perairan Tanjung Guruo-Teluk Wasile-
Tanjung Hatetabako-Tanjung Nyaolako-Puo- Halmahera Timur, Perairan Loleba-Saramaake-Wasile-Pulau Roni-Wasile Selatan


Sumber : RPJMD Kab Halmahera Timur 2021 - 2025


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>