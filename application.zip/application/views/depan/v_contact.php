
<section class="contact-section">
            <div class="container">
                <div class="d-none d-sm-block mb-5 pb-4">
                    
                                        
                    
                    <div class="row">
                   
                         <div class="col-xl-3 col-md-6 col-lg-3">
                       
                            <?php foreach ($kontakkami->result() as $row) : ?>
                        <div class="media contact-info">
                            <span class="contact-info__icon"><i class="ti-home"></i></span>
                            <div class="media-body">
                                
                                <p><?php echo $row->kontakkami_jl;?></p>
                            </div>
                        </div>
                        <div class="media contact-info">
                            <span class="contact-info__icon"><i class="ti-tablet"></i></span>
                            <div class="media-body">
                                
                                <p><?php echo $row->kontakkami_hp;?></p>
                            </div>
                        </div>
                        <div class="media contact-info">
                            <span class="contact-info__icon"><i class="ti-email"></i></span>
                            <div class="media-body">
                                
                                <p><?php echo $row->kontakkami_email;?></p>
                            </div>
                        </div>
                         <div class="d-flex justify-content-start mt-4">
                    <a class="btn btn-outline-light rounded-circle text-center mr-2 px-0" style="background-color: grey; width: 38px; height: 38px;" href="<?php echo $row->kontakkami_twiter;?>"><i class="fab fa-twitter"></i></a>
                    <a class="btn btn-outline-light rounded-circle text-center mr-2 px-0" style="background-color: grey; width: 38px; height: 38px;" href="<?php echo $row->kontakkami_facebook;?>"><i class="fab fa-facebook-f"></i></a>
                    <a class="btn btn-outline-light rounded-circle text-center mr-2 px-0" style="background-color: grey; width: 38px; height: 38px;" href="<?php echo $row->kontakkami_instagram;?>"><i class="fab fa-instagram"></i></a>
                    <a class="btn btn-outline-light rounded-circle text-center mr-2 px-0" style="background-color: grey; width: 38px; height: 38px;" href="<?php echo $row->kontakkami_youtube;?>"><i class="fab fa-youtube"></i></a>
                </div>
                        </div>
                    
                    <div class="col-xl-3 col-md-6 col-lg-3">
                        
                            <iframe src="<?php echo $row->kontakkami_map;?>" width="700" height="400" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                       
                    </div>
                      
                   
            
                 <?php endforeach;?>
                    </div>
                    
    
                </div>
    
    
                
            </div>
        </section>