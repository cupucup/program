<!-- Masthead--><title>Portal Lapor Dan Aspirasi </title><link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('');?>style/img/haltimmm.png"><link href="<?= base_url('style/'); ?>css/home.css" rel="stylesheet" />
<header class="masthead">
    <div class="container h-100">
        <div class="row h-100 align-items-center justify-content-center text-center">
            <div class="col-lg-10 align-self-end">
                <h1 class="text-uppercase text-white font-weight-bold">Portal<br> Layanan Aspirasi dan Pengaduan Online Rakyat</h1>
                <hr class="divider my-4" />
            </div>
            <div class="col-lg-8 align-self-baseline">
                <p class="text-white-75 font-weight-light mb-5">Laporkan setiap kejadian yang meresahkan dan yang dapat merugikan lingkungan demi lingkungan yang lebih baik.</p>
                <a class="btn btn-info btn-xl js-scroll-trigger" href="https://lapor.go.id/instansi/pemerintah-kabupaten-halmahera-timur" target="_blank">Lapor<br><img src="<?php echo base_url('style/img/ikon/logo.png');?>" width="" height=""></a>
                <!-- <a class="btn btn-info btn-xl js-scroll-trigger" href="<?= site_url('auth'); ?>" target="_blank">Aspirasi<br> <img src="<?php echo base_url('style/img/ikon/ikon10.png');?>"  width="" height=""></a>
             -->
                      
               
            </div>
        </div>
    </div>
</header>