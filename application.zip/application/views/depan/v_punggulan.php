<br><br><br><div class="event_details_area ">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="single_event d-flex align-items-center">
                        <div class="thumb">
                        
                    
                        <div class="event_details_info">
                            <div class="event_info">
                                <h2 style=" font-weight: bold; text-align: center;">POTENSI KAWASAN STRATEGIS<br>
KAB HALMAHERA TIMUR</h2>
                                
                            </div>
                            <div class="feature-img">
                     <img class="img-fluid" src="<?php echo base_url('');?>style/img/post/pdaerah.jpeg" >
                  </div>
                     <br>
<p>
1.  kawasan strategis dari sudut kepentingan ekonomi terdiri atas<br>
<p style="text-indent:50px; text-align:justify;">a.  Rencana Pengembangan Kawasan Ekonomi Khusus di Desa Wailukum Kec. Kota Maba;<br>
<p style="text-indent:50px; text-align:justify;">b.  Kawasan Simpul Ekonomi Kabupaten yang terdapat di Kota Maba Kecamatan Kota Maba, Buli Kecamatan Maba, Subaim <p style="text-indent:50px; text-align:justify;">Kecamatan Wasile, dan Nusa Jaya Kecamatan Wasile selatan;<br>
<p style="text-indent:50px; text-align:justify;">c.  Kawasan Pengembangan Tanaman Pangan dan Perkebunan terdiri atas :<br>
<p style="text-indent:90px; text-align:justify;">1)  Kawasan tanaman pangan terdapat di Kawasan transmigrasi Patlean Kecamatan<br>
<p style="text-indent:90px; text-align:justify;">2)  Kawasan tanaman hortikultura dan kelapa sawit terdapat di Kecamatan Maba Selatan<br>
<p style="text-indent:90px; text-align:justify;">3)  Kawasan sawah tadah hujan terdapat di Kawasan transmigrasi Maba kecamatan Kota Maba<br>
<p style="text-indent:50px; text-align:justify;">d.  Kawasan Pengembangan Perikanan, terdiri atas :<br>
<p style="text-indent:90px; text-align:justify;">1)  Kawasan Perikanan tangkap dan budidaya laut terdapat di Kecamatan Maba Selatan<br>
<p style="text-indent:90px; text-align:justify;">2)  Kawasan perikanan tangkap dan sumberdaya kelautan dengan komoditas seperti cumi dan ubur-ubur yang terdapat <p style="text-indent:90px; text-align:justify;">di Nusa Jaya Kecamatan Wasile Selatan<br>
<p style="text-indent:50px; text-align:justify;">e.  Kawasan pembangunan industri nikel yang terdapat di Kecamatan Kota Maba, Maba dan Wasile Selatan<br>
<p style="text-indent:50px; text-align:justify;">f.  Kawasan Pengembangan Pariwisata terdiri atas :<br>
<p style="text-indent:90px; text-align:justify;">1)  Kawasan wisata bahari, terdapat di Jara-jara<br>
<p style="text-indent:90px; text-align:justify;">2)  Kawasan wisata bahari dan konservasi laut terdapat di Teluk Buli<br>
2.  Kawasan Strategis Kabupaten dari sudut kepentingan sosial budaya yaitu Kawasan seni dan suku asli Halmahera Timur<br>
3.  Kawasan strategis untuk kepentingan fungsi dan daya dukung lingkungan hidup terdapat di Taman Nasional Lolobata dan Aketajawe<br>
sumber : RPJMD Kab Halmahera Timur 2021 - 2025
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>