<?php
        function limit_words($string, $word_limit){
            $words = explode(" ",$string);
            return implode(" ",array_splice($words,0,$word_limit));
        }
    ?>
<title><?php echo $title;?></title>
<script type="text/javascript">
    $(document).ready(function(){
        $('a.close').click(function(eve){
            
            eve.preventDefault();
            $(this).parents('div.popup').fadeOut('slow');
        });
    });
    
</script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
<style>

div.popup{
        position:fixed;
        top:0;
        bottom:0;
        left:0;
        right:0;
        width: auto;
        height: auto;
        background: rgba(0,0,0,.8);
        z-index: 1;
    }
    
    div#box{
        margin:5% auto;
        background:#fff;
        width:50%;
        height:50%;
        -webkit-box-shadow:0 0 15px #000;
        -moz-box-shadow:0 0 15px #000;
        box-shadow:0 0 15px #000;
    }
    
    a.close{
        text-decoration:none;
        color:#000;
        margin:10px 15px 0 0;
        float:right;
        font-family:tahoma;
        font-size:20px;
    }
*{
    margin: 0;
    padding: 0;
    list-style: none;
    text-decoration: none;
}
.slider{
    overflow: hidden;
    height: 100%;
    
}

.slider figure div{
    width: 20%;
    float: left;
}

.slider figure img{
    width: 100%;
    float: left;
}

.slider figure{
    position: relative;
    width: 500%;
    margin: 0;
    left: 0;
    animation: 60s slidy infinite;
}

@keyframes slidy{
    0%{
        left: 0%
    }

    10%{
        left: 0%;
    }

    12%{
        left: -100%;
    }

    22%{
        left: -100%;
    }

    24%{
        left: -200%;
    }

    34%{
        left: -200%;
    }

    36%{
        left: -300%;
    }

    46%{
        left: -300%;
    }

    48%{
        left: -400%;
    }

    58%{
        left: -400%;
    }

    60%{
        left: -300%;
    }

    70%{
        left: -300%;
    }

    72%{
        left: -200%;
    }

    82%{
        left: -200%;
    }

    84%{
        left: -100%;
    }

    94%{
        left: -100%;
    }

    96%{
        left: 0%;
    }

    100%{
        left: 0%;
    }
}
</style>

<div class="slider">
        <figure>
            <div class="slide">
                <img src="<?php echo base_url('');?>style/img/banner/pka.png">
            </div>

            <div class="slide">
                <img src="<?php echo base_url('');?>style/img/banner/backg.jpg">
            </div>
            <div class="slide">
                <img src="<?php echo base_url('');?>style/img/banner/pka.png">
            </div>

            <div class="slide">
                <img src="<?php echo base_url('');?>style/img/banner/backg.jpg">
            </div>
            <div class="slide">
                <img src="<?php echo base_url('');?>style/img/banner/pka.png">
            </div>
        </figure>
    </div>

<!-- bagian popup 
    <div class="popup">
        <div id="box"><iframe src="<?php echo base_url('');?>style/img/banner/puasa.pdf" width="400" height="600"></iframe> <div class="slider">
        <figure>
            <div class="slide">
                <a class="weatherwidget-io" href="https://forecast7.com/en/1d31128d48/east-halmahera-regency/" data-label_1="CUACA" data-label_2="HALMAHERA TIMUR" data-theme="original" >HALMAHERA TIMUR CUACA</a>
                        <script>
                        !function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src='https://weatherwidget.io/js/widget.min.js';fjs.parentNode.insertBefore(js,fjs);}}(document,'script','weatherwidget-io-js');
                        </script>
            </div>

            <div class="slide">
                <img src="<?php echo base_url('');?>style/img/banner/img_nature_wide.jpg">
            </div>

            <div class="slide">
                <img src="<?php echo base_url('');?>style/img/banner/img_mountains_wide.jpg">
            </div>

            <div class="slide">
                <img src="<?php echo base_url('');?>style/img/banner/img_snow_wide.jpg">
            </div>

            <div class="slide">
                <img src="<?php echo base_url('');?>style/img/banner/img_nature_wide.jpg">
            </div>
        </figure>
    </div>
            <a class="close" href="#">X</a>
        </div>      
    </div> -->
    <!-- akhir dari popup -->

<!-- Team Start -->
        <div class="team">
            <div class="container">
                <div class="section-header text-center">
                    <p>Kepala Bupati Dan Wakil</p>
                    <h2>Mengetahui Kepala Bupati, Wakil Bupati Dan Sekretaris Daerah</h2>
                </div>
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="team-item">
                            <div class="team-img" height="250px">
                                <a href="<?php echo base_url('bupati');?>"><img src="style/img/experts/bupatii.jpg"></a>
                            </div>
                            <div class="team-text">
                                <a href="<?php echo base_url('bupati');?>"><h2>Drs. H. Ubaid Yakub, MPA</h2></a>
                                <p>Bupati Halmahera Timur</p>
                                <!-- <div class="team-social">
                                    <a href=""><i class="fab fa-twitter"></i></a>
                                    <a href=""><i class="fab fa-facebook-f"></i></a>
                                    <a href=""><i class="fab fa-linkedin-in"></i></a>
                                    <a href=""><i class="fab fa-instagram"></i></a>
                                </div> -->
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="team-item">
                            <div class="team-img" height="250px">
                                <a href="<?php echo base_url('wakilbupati');?>"><img src="style/img/experts/wakilbupati.png"></a>
                            </div>
                            <div class="team-text">
                                <a href="<?php echo base_url('wakilbupati');?>"><h2>ANJAS TAHER, SE.,M.Si</h2></a>
                                <p>Wakil Bupati Halmahera Timur</p>
                                <!-- <div class="team-social">
                                    <a href=""><i class="fab fa-twitter"></i></a>
                                    <a href=""><i class="fab fa-facebook-f"></i></a>
                                    <a href=""><i class="fab fa-linkedin-in"></i></a>
                                    <a href=""><i class="fab fa-instagram"></i></a>
                                </div> -->
                            </div>
                        </div>
                    </div>    
                    <div class="col-lg-3 col-md-6">
                        <div class="team-item">
                            <div class="team-img" height="250px">
                               <a href="<?php echo base_url('sekda');?>"> <img src="style/img/experts/SEKDA.png"></a>
                            </div>
                            <div class="team-text">
                                <a href="<?php echo base_url('sekda');?>"><h2>Ricky Chairul Richfat, ST.,MT</h2></a>
                                <p>Sekertaris Daerah Halmahera Timur</p>
                                <!-- <div class="team-social">
                                    <a href=""><i class="fab fa-twitter"></i></a>
                                    <a href=""><i class="fab fa-facebook-f"></i></a>
                                    <a href=""><i class="fab fa-linkedin-in"></i></a>
                                    <a href=""><i class="fab fa-instagram"></i></a>
                                </div> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Team End -->
    <!--==========================
      About Us Section
    ============================-->
    <div class="team">
            <div class="container">
                <div class="section-header text-center">
                  
                </div>
                <div class="row"><?php foreach ($guru->result() as $row) : ?>
                    <div class="col-lg-3 col-md-6">
                        <div class="team-item">
                            <div class="team-img" height="250px">
                                <a href="<?php echo site_url('pegawai/dtlp/'.$row->guru_id);?>"><img src="<?php echo base_url().'assets/images/'.$row->guru_photo;?>" alt="<?php echo $row->guru_nama;?>"></a>
                            </div>
                            <div class="team-text">
                                <a href="<?php echo site_url('pegawai/dtlp/'.$row->guru_id);?>"><h2><?php echo $row->guru_nama;?></h2></a>
                                <p><?php echo $row->pegawai_jabatan;?></p>
                                <!-- <div class="team-social">
                                    <a href=""><i class="fab fa-twitter"></i></a>
                                    <a href=""><i class="fab fa-facebook-f"></i></a>
                                    <a href=""><i class="fab fa-linkedin-in"></i></a>
                                    <a href=""><i class="fab fa-instagram"></i></a>
                                </div> -->
                            </div>
                        </div>
                    </div>
                        <?php endforeach;?>
                    
                </div>
            </div>
        </div>
        <!-- Team End -->
    <section id="about">
      <div class="container">

        <header class="section-header text-center">
          <h3>Sekilas halmahera Timur</h3>
          <p>Kabupaten Halmahera Timur adalah salah satu kabupaten yang berada di provinsi Maluku Utara, Indonesia. Pusat pemerintahan atau ibukota kabupaten ini berada di kecamatan Kota Maba. Penduduk kabupaten Halmahera Timur pada tahun 2020 berjumlah 91.707 jiwa, dengan kepadatan 14 jiwa/km2</p>
        </header>

        <div class="row about-cols">

          <div class="col-md-4 wow fadeInUp">
            <div class="about-col">
              <div class="img">
                
              </div><br>
              <h2 class="title"><a href="#">Visi</a></h2>
              <p>
                "Terwujudnya Kabupaten Halmahera Timur yang Maju, Mandiri, dan Sejahtera"

              </p>
            </div>
          </div>

          <div class="col-md-4 wow fadeInUp" data-wow-delay="0.1s">
            <div class="about-col">
              <div class="img">
                <img src="style/img/about/profil.png" alt="" class="img-fluid">
              </div>
              
            </div>
          </div>

          <div class="col-md-4 wow fadeInUp" data-wow-delay="0.2s">
            <div class="about-col">
              <div class="img">
                
              </div><br>
              <h2 class="title"><a href="#">Misi</a></h2>
              <p>
               1. Meningkatkan Pelayanan Dasar di Bidang Pendidikan dan Bidang Kesehatan<br>
2. Meningkatkan Pembangunan Infrastruktur Transportasi, Infastruktur Pertanian Kelautan Perikanan, Pemukiman<br>
3. Mengembangkan Perekonomian Berbasis Potensi Lokal Secara Berkelanjutan<br>
4. Mewujudkan Tata Kelola Pemerintahan yang Berkualitas<br>
5. Memperkuat Harmoni Sosial dan Budaya di Tengah Masyarakat.<br>
              </p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- #about -->
   
    <!-- About Start -->
        <div class="abt" id="abt">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="abt-img" data-parallax="scroll" data-image-src="style/img/atas.jpg"></div>
                    </div>
                    <div class="col-md-4">
                        <div class="section-header">
                            <p>Widget</p>
                            <h2>Kominfo Dan Cuaca</h2>
                        </div>
                        <div class="abt-tab">
                            <ul class="nav nav-pills nav-justified">
                                <li class="nav-item">
                                    <a class="nav-link active" data-toggle="pill" href="#tab-content-1" style="color: black;">Widget Kominfo</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" data-toggle="pill" href="#tab-content-2" style="color: black;">Cuaca</a>
                                </li>
                            </ul>

                            <div class="tab-content">
                                <div id="tab-content-1" class="container tab-pane active">
                               <div id="gpr-kominfo-widget-container" class="footer_widget"></div>
                                </div>
                                <div id="tab-content-2" class="container tab-pane fade">
                               <a class="weatherwidget-io" href="https://forecast7.com/en/1d31128d48/east-halmahera-regency/" data-label_1="CUACA" data-label_2="HALMAHERA TIMUR" data-theme="original" >HALMAHERA TIMUR CUACA</a>
                        <script>
                        !function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src='https://weatherwidget.io/js/widget.min.js';fjs.parentNode.insertBefore(js,fjs);}}(document,'script','weatherwidget-io-js');
                        </script>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- About End -->
<div class="container pt-5" id="Berita">
        <div class="d-flex flex-column text-center mb-5">
            <h4 class="text-secondary mb-3"></h4>
            <h1 class="display-4 m-0"><span class="text-primary">Berita Kab</span>&nbsp;Halmahera Timur</h1>
        </div>
        <div class="row pb-3">
             <?php  foreach ($berita->result() as $row) :?>
            <div class="col-lg-4 mb-4">
                <div class="card border-0 mb-2"><a href="<?php echo site_url('artikel/'.$row->tulisan_slug);?>">
                    <img class="card-img-top" src="<?php echo base_url().'assets/images/'.$row->tulisan_gambar;?>" alt="<?php echo $row->tulisan_judul;?>" height="230px" width="100%"></a>
                    <div class="card-body bg-light p-4">
                        <h4 class="card-title text-truncate"><a href="<?php echo site_url('artikel/'.$row->tulisan_slug);?>">
                                <h4><?php echo $row->tulisan_judul;?></h4>
                            </a></h4>
                        <div class="d-flex mb-3">
                            <small class="mr-2"><i class="fa fa-calendar text-muted"></i><?php echo $row->tanggal;?></small>
                            <small class="mr-2"><i class="fa fa-folder text-muted"></i><a href="<?php echo site_url('blog/kategori/'.str_replace(" ","-",$row->tulisan_kategori_nama));?>" class="show"><?php echo $row->tulisan_kategori_nama;?></a></small>
                            <small class="mr-2"><i class="fa fa-eye text-muted"></i>&nbsp;<?php echo $row->tulisan_views;?></small>
                        </div>
                        <p><?php echo limit_words($row->tulisan_isi,10).'...';?></p>
                        <a class="tombol" href="<?php echo site_url('artikel/'.$row->tulisan_slug);?>">Read More</a>
                    </div>
                </div>
            </div>
           
        <?php endforeach;?></div>
    </div>
    <!--/ service_area_start  -->

    <!-- popular_program_area_start  -->
    <div class="popular_program_area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section_title text-center">
                        <h3>Pengumuman </h3>
                    </div>
                </div>
            </div>
            
            <div class="tab-content" id="nav-tabContent">
                <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                    <div class="row">
                        
                        
                
                
                        <?php foreach ($pengumuman->result() as $row) :?>
                        <div class="col-lg-4 col-md-6">
                            <div class="single__program">
                                <div class="program_thumb">
                                    <img src="img/program/1.png" alt="">
                                </div>
                                <div class="program__content">
                                    <span><?php echo $row->tanggal;?></span>
                                    <h4><a href="<?php echo site_url('pengumuman');?>"><?php echo $row->pengumuman_judul;?></a></h4>
                                    <p><?php echo limit_words($row->pengumuman_deskripsi,10).'...';?></p>
                                    <a href="<?php echo site_url('pengumuman');?>" class="boxed-btn5">Selengkapnya</a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach;?>
                        
                        
                        
                    </div>
                </div>
                
                
                
            </div>

            <div class="row">
                <div class="col-lg-12">
                    <div class="course_all_btn text-center">
                        <a href="<?php echo site_url('pengumuman');?>" class="boxed-btn4">Lihat Semua Pengumuman</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- popular_program_area_end -->

    <!-- latest_coures_area_start  -->
    
    <!--/ latest_coures_area_end -->

    <!-- recent_event_area_strat  -->
    <div class="recent_event_area section__padding">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8 col-md-10">
                    <div class="section_title text-center mb-70">
                        <h3 class="mb-45">Agenda Halmahera Timur</h3>
                        
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    
                    
                    <?php foreach ($agenda->result() as $row):?>
                    <div class="single_event d-flex align-items-center">
                        <div class="date text-center">
                            
                        </div>
                        <div class="event_info">
                           <a href="<?php echo site_url('agenda/dtlagenda/'.$row->agenda_id);?>">  <h4><?php echo $row->agenda_nama;?></h4></a>
                            <p><?php echo limit_words($row->agenda_deskripsi,10).'...';?></p>
                        </div>
                    </div>
                    <?php endforeach;?>
                </div>
            </div>
        </div>
    </div>
