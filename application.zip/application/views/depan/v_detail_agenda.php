 
<?php foreach ($data->result() as $row) : ?>
<br>
<!doctype html>
 <html>
 <head>
 <title><?php echo $row->agenda_nama;?></title>
<head>
 <body>
   <div class="row justify-content-center">
                <div class="col-lg-8 col-md-10">
                    <div class="section_title text-center mb-70">
                        <h3 class="mb-45"><?php echo $row->agenda_nama;?></h3>
                        
                    </div>
                </div>
            </div>
 <form action="#" style="width: 1000px;padding-left: 100px;"class="posisi";>
 <fieldset class="h"/>
 <table style="width: 980px;">
 
 &nbsp;
 <tr>
    <td>Nama Agenda</td>
    <td>:</td>
    <td><?php echo $row->agenda_nama;?></td>
  </tr>
   
  <tr>
    <td>Deskrifsi agenda</td>
        <td>:</td>

    <td><?php echo $row->agenda_deskripsi;?></td>
  </tr>
  <tr>
    <td>Tanggal Mulai</td>
        <td>:</td>

    <td><?php echo $row->agenda_mulai;?></td>
  </tr>
  <tr>
    <td>Tanggal Selesai</td>
        <td>:</td>

    <td><?php echo $row->agenda_selesai;?></td>
  </tr>
  <tr>
    <td>Tempat Agenda</td>
        <td>:</td>

    <td><?php echo $row->agenda_tempat;?></td>
  </tr>
 <tr>
    <td>Waktu Agenda</td>
        <td>:</td>

    <td><?php echo $row->agenda_waktu;?></td>
  </tr>
  <tr>
    <td>Keterangan Agenda</td>
        <td>:</td>

    <td><?php echo $row->agenda_keterangan;?></td>
  </tr>
 </table>
 </fieldset>
 </form>
 <br>
 </body>
 </html><?php endforeach;?>