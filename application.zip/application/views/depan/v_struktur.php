<br><div class="event_details_area ">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="single_event d-flex align-items-center">
                        <div class="thumb">
                        
                    
                        <div class="event_details_info">
                            <div class="event_info">
                                <h2 style=" font-weight: bold; text-align: center;">Struktur Pemerintahan</h2>
                                
                            </div></div></div>
                </div>
            </div>
        </div>
    </div>
<div class="feature-img" style="padding-left: 4%;">
                     <img class="img-fluid" src="<?php echo base_url('');?>style/img/banner/strukturpemerintahan.png" width="100%" height="700px">
                  </div>
                  <br>