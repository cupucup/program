
<div class="recent_event_area ">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8 col-md-10">
                    <div class="section_title text-center mb-70">
                        <h3 class="mb-45">SEKERTARIS DAERAH</h3>
                        
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-10">
                     <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="team-item">
                            <div class="team-img" height="250px">
                                <img src="style/img/experts/wakil.jpg">
                            </div>
                           
                        </div>
                    </div>
                       
                    
                </div>
              <table>
  <tr>
    <th>Nama</th>
    <th>ANJAS TAHER, SE.,M.Si</th>
  </tr>
  <tr>
    <td>Tempat/Tgl Lahir</td>
    <td>Ekor 02 Mei 1973</td>
  </tr>
  <tr>
    <td>Istri</td>
    <td>Ny. Ema H. Hanafi</td>
  </tr>
  <tr>
    <td>Anak</td>
    <td>•   M. Akbar Taher</td>
  </tr>
  <tr>
    <td></td>
    <td>•   Aliyah Jatilhima</td>
  </tr>
  <tr>
    <td>Anak</td>
    <td>•   M. Emil Rizkullah</td>
  </tr>
  <tr>
    <td></td>
    <td>•   M. Imam Sidik Hilmi</td>
  </tr>
 
  <tr>
    <td>Pendidikan Formal</td>
    <td>•   SD Negeri Ekor</td>
  </tr>
  <tr>
    <td></td>
    <td>•   SMP GMIH Ternate</td>
  </tr>
  <tr>
    <td></td>
    <td>•   SMA PGRI Palu (1989-1992)</td>
  </tr>
  <tr>
    <td></td>
    <td>•   S1 Universitas Khairun Ternate (1993-1997)</td>
  </tr>
  <tr>
    <td></td>
    <td>•   S2 Institut Pertanian Bogor (2009-2011)</td>
  </tr>
  <tr>
    <td>Riwayat Pekerjaan</td>
    <td>•   Ketua Komisi II DPRD Halmahera Timur (2004-2009)</td>
  </tr>
  <tr>
    <td></td>
    <td>•   Ketua DPRD Halmahera Timur (2009-2014)</td>
  </tr>
  <tr>
    <td></td>
    <td>•   Anggota DPRD Provinsi Maluku Utara (2017-2019)</td>
  </tr>
  <tr>
    <td></td>
    <td>•   Wakil Bupati Halmahera Timur (2021-Sekarang)</td>
  </tr>
  
  <tr>
    <td>Riwayat Organisasi</td>
    <td>•   Ketua  HMI Komisariat Ekonomi Unkhair Ternate (1993)</td>
  </tr>
  <tr>
    <td></td>
    <td>•   Wakil Ketua Umum HMI Cabang Ternate (1995)</td>
  </tr>
  <tr>
    <td></td>
    <td>•   Sekretaris DPD II Partai Golkar (2004-2013)</td>
  </tr>
  <tr>
    <td></td>
    <td>•   Anggota Bappilu DPD I Maluku Utara (2019-2020)</td>
  </tr>
  <tr>
    <td></td>
    <td>•   Ketua DPD II Partai Golkar Halmahera Timur (2021-Sekarang)</td>
  </tr>
  <tr>
    <td></td>
    <td>•   Ketua DPD KAHMI Halmahera Timur (2022-Sekarang)</td>
  </tr>
  
</table>
    </div>
            </div>
        </div>
    </div><br>