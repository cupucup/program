

<div class="event_details_area ">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="single_event d-flex align-items-center">
                        <div class="thumb">
                            
                            
                        </div><?php foreach($tentangkami->result() as $row):?>
                        <div class="event_details_info">
                            <div class="event_info">
                                <a href="#">
                                    &nbsp;<h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $row->tentangkami_judul;?></h4>
                                 </a>
                                <p><span> <i class="flaticon-clock"></i>&nbsp;&nbsp; 10:30 pm</span> <span> <i class="flaticon-calendar"></i>  2022 </span> <span> <i class="flaticon-placeholder"></i> Halmahera Timur</span> </p>
                            </div>
                            <p style="text-indent:50px; text-align:justify;"><?php echo $row->tentangkami_deskripsi;?></p>
<br><br>


                            
                        </div><?php endforeach;?>
                    </div>
                </div>
            </div>
        </div>
    </div>