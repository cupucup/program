
<div class="recent_event_area ">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8 col-md-10">
                    <div class="section_title text-center mb-70">
                        <h3 class="mb-45">BUPATI</h3>
                        
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-10">
                     <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="team-item">
                            <div class="team-img" >
                                <img src="style/img/experts/bupati.jpg">
                            </div>
                           
                        </div>
                    </div>
                       
                    
                </div>
              <table>
  <tr>
    <th>Nama</th>
    <th>Drs. H. Ubaid Yakub, M.Pa</th>
  </tr>
  <tr>
    <td>Tempat/Tgl Lahir</td>
    <td>Gotowasi, 27 Agustus 1969</td>
  </tr>
  <tr>
    <td>Istri</td>
    <td>Ny. Hj. Sittinur  Hi. Ma’bud</td>
  </tr>
  <tr>
    <td>Anak</td>
    <td>•   Muhammad Ridha Yakub</td>
  </tr>
  <tr>
    <td></td>
    <td>•   Asih Zafirah Yakub</td>
  </tr>
  <tr>
    <td>Pendidikan Formal</td>
    <td>•   SD Negeri Gotowasi</td>
  </tr>
  <tr>
    <td></td>
    <td>•   SMP Negeri Buli</td>
  </tr>
  <tr>
    <td></td>
    <td>•   SMA Negeri Labuha (1985-1988)</td>
  </tr>
  <tr>
    <td></td>
    <td>•   S1 IAIN Alaudin Makassar (1989 - 1992)</td>
  </tr>
  <tr>
    <td></td>
    <td>•   S2 Universitas Gadjah Mada (2008-2010)</td>
  </tr>
  <tr>
    <td>Riwayat Pekerjaan</td>
    <td>•   Kepala Seksi Pendidikan Dasar Dan Prasekolah Dinas Pendidikan, Kebudayaan Dan Parawisata  Halmahera Timur (2004-2006)</td>
  </tr>
  <tr>
    <td></td>
    <td>•   Kepala Bidang Pendidikan Sekolah Luar Biasa dan Pemuda (2007)</td>
  </tr>
  <tr>
    <td></td>
    <td>•   Kepala Dinas Pendidikan Dan Olahraga Tahun (2011-2016)</td>
  </tr>
  <tr>
    <td></td>
    <td>•   Kepala Dinas Perhubungan (2016-2020)</td>
  </tr>
  <tr>
    <td></td>
    <td>•   Bupati Halmahera Timur (2021-Sekarang)</td>
  </tr>
  <tr>
    <td>Riwayat Organisasi</td>
    <td>•   Ketua PC Muhammadiyah Kota Maba</td>
  </tr>
  <tr>
    <td></td>
    <td>•   Sekretaris Umum Koni Halmahera Timur</td>
  </tr>
</table>
    </div>
            </div>
        </div>
    </div><br>