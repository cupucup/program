<div class="bradcam_area breadcam_bga">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="thumb">
                        
                    
                        <div class="event_details_info">
                            <div class="event_info">
                                <h2 style=" font-weight: bold; text-align: center;">POTENSI DAERAH
<br>
KAB HALMAHERA TIMUR</h2>
                                
                            </div></div></div>
                </div>
            </div>
        </div>
    </div>
<div class="feature-img">
                     <img class="img-fluid" src="<?php echo base_url('');?>style/img/post/pdaerah.jpeg" >
                  </div>
                  <br>