<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<!-- Global site tag (gtag.js) - Google Analytics -->
<script type="text/javascript" async="" src="https://www.google-analytics.com/analytics.js"></script>
<script async="" src="https://www.google-analytics.com/analytics.js"></script>
<script type="text/javascript" async="" src="https://www.google-analytics.com/analytics.js"></script>
<script async="" src="https://www.google-analytics.com/analytics.js"></script>
<script async="" src="https://www.googletagmanager.com/gtag/js?id=UA-154801838-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-154801838-1');
</script>
	<title>Portal Resmi Pemerintah Kabupaten Halmahera Timur</title>
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('');?>style/img/ikon/icon.png">
	<meta name="description" content="Portal Resmi Pemerintah Kabupaten Halmahera Timur,Kabupaten Halmahera Timur, Pemerintah Kabupaten Halmahera Timur, portal pemerintah Kabupaten Halmahera Timur">
	<meta name="keywords" content="Kabupaten Halmahera Timur, Pemerintah Kabupaten Halmahera Timur, portal pemerintah Kabupaten Halmahera Timur">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" content="">
	<link rel="stylesheet" href="<?php echo base_url('style/css/style.css')?>"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('');?>style/css/style_landing_page.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="style/css/search.css">
	
    <!-- CSS here -->
    <link rel="stylesheet" href="<?php echo base_url('');?>style/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url('');?>style/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo base_url('');?>style/css/magnific-popup.css">
    <link rel="stylesheet" href="<?php echo base_url('');?>style/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo base_url('');?>style/css/themify-icons.css">
    <link rel="stylesheet" href="<?php echo base_url('');?>style/css/nice-select.css">
    <link rel="stylesheet" href="<?php echo base_url('');?>style/css/flaticon.css">
    <link rel="stylesheet" href="<?php echo base_url('');?>style/css/gijgo.css">
    <link rel="stylesheet" href="<?php echo base_url('');?>style/css/animate.css">
    <link rel="stylesheet" href="<?php echo base_url('');?>style/css/slicknav.css">
    <link rel="stylesheet" href="<?php echo base_url('');?>style/css/style.css">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="<?php echo base_url().'theme/css/dataTables.bootstrap4.min.css'?>" rel="stylesheet">
    <!-- Google Web Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat&family=Oswald:wght@400;500;600&display=swap" rel="stylesheet"> 

        <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap" rel="stylesheet">
        
      <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Montserrat:300,400,500,700" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<script type="text/javascript">
      (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-85280822-1', 'auto');
  ga('send', 'pageview');
</script></head>
<style>
body {
  background-image: url('style/img/background/bcgg.png');
  background-color: rgba(0,0,0,0.658);
  background-blend-mode:overlay;
  background-size: cover;
   background-position: center center;
    background-repeat: no-repeat;
     background-attachment: fixed;
  
}

</style>

<!-- 	
<img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-wp-preserve="%3Cstyle%3E%3C%2Fspan%3E%0A%0A%3Cspan%20style%3D%22font-family%3A%20'verdana'%20%2C%20sans-serif%3B%22%3E%0Abody%7Bmargin%3A0%3Bbackground%3A%23000%7D%0Avideo%7Bposition%3Afixed%3Btop%3A50%25%3B%0Aleft%3A50%25%3Bmin-width%3A100%25%3B%0Amin-height%3A100%25%3B%0Awidth%3Aauto%3B%0Aheight%3Aauto%3B%0Az-index%3A-100%3B%0A-webkit-transform%3AtranslateX(-50%25)%20translateY(-50%25)%3B%0Atransform%3AtranslateX(-50%25)%20translateY(-50%25)%3B%0Abackground%3Aurl(%3Cb%3Ealamat%20gambar%20background%20alternatif%3C%2Fb%3E)%0A%20no-repeat%3Bbackground-size%3Acover%3B%0A-webkit-transition%3A1s%20opacity%3Btransition%3A1s%20opacity%7D%0A%7D%3C%2Fspan%3E%0A%0A%3Cspan%20style%3D%22font-family%3A%20'verdana'%20%2C%20sans-serif%3B%22%3E%3C%2Fstyle%3E" data-mce-resize="false" data-mce-placeholder="1" class="mce-object" width="20" height="20" alt="&lt;style&gt;" title="&lt;style&gt;" /> -->


	<!-- <body style="background-image: url('c.jpeg'); overflow: auto; background-size: 100%; max-width: auto; max-height: auto; background-repeat: no-repeat;"> -->
	<!-- <body class="bg-layer"> -->
	<body>
<!--Logo-->
<!-- <video autoplay loop poster="<?php echo base_url('');?>style/img/background/bgg.jpeg" >
<source src="<?php echo base_url('');?>style/img/bacground/vid.mp4" type="video/mp4">
</video> -->
<div class="header-top_area" style="background: #A6C3C5;">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="header_top_wrap d-flex justify-content-between align-items-center">
                                
                                    <div class="d-flex justify-content-start mt-4">
                                    	<a class="btn btn-outline-light rounded-circle text-center mr-2 px-0" style="width: 38px; height: 38px;" href="#"><i class="fab fa-instagram"></i></a>
                                    	<a class="btn btn-outline-light rounded-circle text-center mr-2 px-0" style="width: 38px; height: 38px;" href="#"><i class="fab fa-facebook-f"></i></a>
                                    	<a class="btn btn-outline-light rounded-circle text-center mr-2 px-0" style="width: 38px; height: 38px;" href="https://www.youtube.com/channel/UC_iKSQgAVWqnYZ06vvcJneA"><i class="fab fa-youtube"></i></a>
                    <a class="btn btn-outline-light rounded-circle text-center mr-2 px-0" style="width: 38px; height: 38px;" href="https://twitter.com/haltimkab"><i class="fab fa-twitter"></i></a>
                    
                    
                </div>
                                <div class="text_wrap"><p></p></div><div class="text_wrap"><p></p></div><div class="text_wrap"><p></p></div><div class="text_wrap"><p></p></div><div class="text_wrap"><p></p></div><div class="text_wrap"><p></p></div>
                                <div class="text_wrap" id="eml" style="color: white; padding-left: -0%;"><a href="mailto:haltim@haltimkab.go.id"><i class="fa fa-envelope"></i>&nbsp;<span>Email : haltim@haltimkab.go.id</span></a></div>

                                <div class="text_wrap">
                                    <p><form action="<?php echo site_url('blog/search');?>" method="get">
                                <div class="form-group">
                                    <div class="input-group mb-3">
                                        <input type="text" name="keyword" class="form-control" placeholder='Search '
                                            onfocus="this.placeholder = ''"
                                            onblur="this.placeholder = 'Search'" autocomplete="off" required>
                                        <div class="input-group-append">
                                            <button class="btn" type="submit"><i class="ti-search"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <div class="modal fade" id="ModalSearch" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" style="z-index: 10000;">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-body">  
                <form action="<?php echo site_url('blog/search');?>" method="GET">
                    <div class="input-group">
                      <input type="text" name="search_query" class="form-control input-search" style="height: 40px;" placeholder="Cari..." required>
                      <span class="input-group-btn">
                        <button class="btn btn-default" type="submit" style="height: 40px;background-color: #ccc;"><span class="fa fa-search"></span></button>
                      </span>
                    </div>
                </form>
              </div>
            </div>
          </div>
        </div></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        
	<div class="logo">
		<img src="<?php echo base_url('');?>style/img/halmah.png" style="margin-top:1%; width: 10%; height: 20%"></img><br>
		<H2 style="color:  #A6C3C5; text-shadow: #A6C3C5; 5px 5px;">PORTAL RESMI<BR>PEMERINTAH KABUPATEN HALMAHERA TIMUR</H2>
		<h3 style="color:white; font-style: italic; font-family: Lucida Console, Courier New, monospace;">Limabot Fayfiye</h3>
</div>
<br>
	<div class="panel_menu wrap ikon">
		<div class="menu ikon">
			<div class="wrap_content" id="dropdown" data-id="atas" style=""><img src="<?php echo base_url('style/img/ikon/ikon1.png');?>" width="100px" height="100px"><div class="font-wrap" id="text-button">Sekilas Halmahera Timur</div></div>
			<div class="wrap_content_active" id="selected" data-id="atas" style="display: none;"><img src="<?php echo base_url('style/img/ikon/ikon1.png');?>" width="10px" height="10px"><div class="font-wrap" id="text-button">Sekilas Halmahera Timur</div></div>
			<div class="font-wrap" id="text-button" style="display:none;">Sekilas Halmahera Timur</div>
			<div class="arrow-up" style="display: none;"></div>
		</div>
		
		<div class="menu ikon">
			<div class="wrap_content" id="dropdown" data-id="atas" style=""><img src="<?php echo base_url('style/img/ikon/ikon2.png');?>" width="100px" height="100px"><div class="font-wrap" id="text-button">Pemerintahan</div></div>
			<div class="wrap_content_active" id="selected" data-id="atas" style="display: none;"><img src="<?php echo base_url('style/img/ikon/ikon2.png');?>" width="100px" height="100px"><div class="font-wrap" id="text-button">Pemerintahan</div></div>
			<div class="font-wrap" id="text-button" style="display:none;">Pemerintahan</div>
			<div class="arrow-up" style="display: none;"></div>
		</div>

		<div class="menu">
			<div class="wrap_content" id="dropdown" data-id="atas" style=""><img src="<?php echo base_url('style/img/ikon/ikon3.png');?>" width="100px" height="100px"><div class="font-wrap" id="text-button">Pelayanan Publik</div></div>
			<div class="wrap_content_active" id="selected" data-id="atas" style="display: none;"><img src="<?php echo base_url('style/img/ikon/ikon3.png');?>" width="100px" height="100px"><div class="font-wrap" id="text-button">Pelayanan Publik</div></div>
			<div class="font-wrap" id="text-button" style="display:none;">Pelayanan Publik</div>
			<div class="arrow-up" style="display: none;"></div>
		</div>
				<div class="menu">
			<div class="wrap_content" id="dropdown" data-id="atas" style=""><img src="<?php echo base_url('style/img/ikon/ikon4.png');?>" width="100px" height="100px"><div class="font-wrap" id="text-button">Smart City</div></div>
			<div class="wrap_content_active" id="selected" data-id="atas" style="display: none;"><img src="<?php echo base_url('style/img/ikon/ikon4.png');?>" width="100px" height="100px"><div class="font-wrap" id="text-button">Smart City</div></div>
			<div class="font-wrap" id="text-button" style="display:none;">Smart City</div>
			<div class="arrow-up" style="display: none;"></div>
		</div>
		<div class="menu">
			<div class="wrap_content"><a href="<?php echo base_url('spbe');?>" target="_blank"><img src="<?php echo base_url('style/img/ikon/ikon5.png');?>" width="100px" height="100px">
				<div class="font-wrap" id="text-button">SPBE</div></a>
			</div>
		</div>


	</div>
	&nbsp;
	<div class="gelembung_informasi" id="atas" style="display: none; background-image: url('style/img/ikon/bck.png'); opacity:0.85;;"><div class="listing"><a href="#"><i class="fa fa-long-arrow-right"></i>Sejarah Kab Halmaher Timur</a><br><br><a href="'https://haltimkab.rahadian-consulting.com/artikel/penjelasan-lambang-kabupaten-halmahera-timur'"><i class="fa fa-long-arrow-right"></i>Lambang Kab Halmahera Timur</a><br><br>	<a href='#'><i class="fa fa-long-arrow-right"></i> Letak</a></div><div class="listing"><a href="#"><i class="fa fa-long-arrow-right"></i>Data Demografis</a><br><br>	<a href="#"><i class="fa fa-long-arrow-right"></i>Peta Kab Halmahera Timur</a></div><div class="listing"><a href="#"><i class="fa fa-long-arrow-right"></i> Kab Halmahera Timur Tempo Dulu</a></div></div>
	<div class="panel_menu wrap">
		<div class="menu">
			<div class="wrap_content" id="dropdown" data-id="bawah" style=""><img src="<?php echo base_url('style/img/ikon/ikon6.png');?>" width="100px" height="100px"><div class="font-wrap" id="text-button">Sektor Unggulan</div></div>
			<div class="wrap_content_active" id="selected" style="display: none;"><img src="<?php echo base_url('style/img/ikon/ikon6.png');?>" width="100px" height="100px"><div class="font-wrap" id="text-button">Sektor Unggulan</div></div>
			<div class="font-wrap" id="text-button" style="display:none;">Sektor Unggulan</div>
			<div class="arrow-up" style="display: none;"></div>
		</div>
		<div class="menu">
			<div class="wrap_content"><a href="https://dpmptsphaltim.rahadian-consulting.com/" target="_blank"><img src="<?php echo base_url('style/img/ikon/ikon7.png');?>" width="100px" height="100px">
				<div class="font-wrap" id="text-button">Investasi</div></a>
			</div>
		</div>
		<div class="menu">
			<div class="wrap_content"><a href="<?php echo base_url('opd');?>" target="_blank"><img src="<?php echo base_url('style/img/ikon/ikon8.png');?>" width="100px" height="100px">
				<div class="font-wrap" id="text-button">Perangkat Daerah</div></a>
			</div>
		</div>
		<div class="menu">
			<div class="wrap_content"><a href="<?php echo base_url('ppid');?>" target="_blank"><img src="<?php echo base_url('style/img/ikon/ikon9.png');?>" width="100px" height="100px">
				<div class="font-wrap" id="text-button">PPID</div></a>
			</div>
		</div>
        <div class="menu">
			<div class="wrap_content"><a href="<?php echo base_url('lapor');?>" target="_blank"><img src="<?php echo base_url('style/img/ikon/ikon10.png');?>" width="100px" height="100px">
				<div class="font-wrap" id="text-button">Suara Rakyat</div></a>
			</div>
		</div>
		
		</div>
	</div>
	<div class="gelembung_informasi" id="bawah" style="display: none; background-image: url('style/img/ikon/bck.png');opacity:0.85;" ><div class="listing"><a href="#"><i class="fa fa-long-arrow-right"></i> Hotel</a><br><br><a href="#"><i class="fa fa-long-arrow-right"></i> Rumah Makan dan Restoran</a><br><br><a href="#"><i class="fa fa-long-arrow-right"></i> Tour dan Travel</a></div><div class="listing"><a href="#"><i class="fa fa-long-arrow-right"></i> Money Changer</a><br><br><a href="#"><i class="fa fa-long-arrow-right"></i> Pusat Perbelanjaan</a><br><br><a href="#"><i class="fa fa-long-arrow-right"></i> Tempat Rekreasi</a></div><div class="listing"><a href="#"><i class="fa fa-long-arrow-right"></i> Jajanan Oleh - Oleh</a><br><br><a href="#"><i class="fa fa-long-arrow-right"></i> Kerajinan dan Sovenir</a><br><br><a href="#"><i class="fa fa-long-arrow-right"></i> Destinasi Wisata</a></div></div>
	&nbsp;
    <div class="homepage">
		<div class="gotolink"><a href="<?php echo base_url('home');?>"  target="_blank" style="color: white;">Beranda</a></div>	
	</div>
 
</table>
	


<script type="text/javascript">
$(document).ready(function(){
	$(".wrap_content#dropdown").click(function(){
		var bagian = $(this).data("id");
		$(".wrap_content_active").hide("slow","linear");
		$(".arrow-up").slideUp("slow","linear");
		$(".wrap_content").show("slow","linear");
		$(".gelembung_informasi#atas").slideUp("slow","linear");
		$(".gelembung_informasi#bawah").slideUp("slow","linear");
			$(this).parent().children(".wrap_content_active").slideToggle("slow","linear");
			$(".wrap_content_active").attr("Id","selected");
			$(this).toggle(250,"linear");
			$(".gelembung_informasi#"+bagian).slideDown("slow","linear");
			//$(this).parent().children(".arrow-up").toggle("slow","linear"); yang asli
			$(this).parent().children(".arrow-up").slideDown("slow","linear");
			$("body").css("overflow-y","scroll");
			$("body").css("overflow-x","hidden");
			$("body").css("background-size","125% 150%");
            var menu 	=  	$(this).parent().children(".wrap_content").children(".font-wrap").html();
		var masukan;
		switch (menu){
			case "Pelayanan Publik":
				masukan = "<div class='listing'><a href='https://disdukcapilhaltim.rahadian-consulting.com/' target='_blank'><i class='fa fa-long-arrow-right'></i>Kependudukan dan Pencatatan Sipil</a><br><br><a href='http://haltimkab.jdihn.go.id/'target='_blank'> JDIHN Kab Halmahera Timur</a></div><div class='listing'><a href='<?php echo base_url('pajak');?>' target='_blank'>Pajak dan Retribusi Daerah</a><br><br><a href='<?php echo base_url('npenting');?>' target='_blank'> No. Telp Penting</a>";
				//masukan = menu;
			break;
			// case "Pengumuman":
			// 	masukan = "<div class='listing'><a>Masih Belum ada</a></div>";
			// break;
			case "Sekilas Halmahera Timur":
				masukan = "<div class='listing' id='text-menu'><a href='https://haltimkab.rahadian-consulting.com/artikel/sejarah-kab-halmahera-timur'target='_blank'><i class='fa fa-long-arrow-right'></i> Sejarah Kab Halmahera Timur</a><br><br><a href='https://haltimkab.rahadian-consulting.com/artikel/penjelasan-lambang-kabupaten-halmahera-timur'target='_blank'><i class='fa fa-long-arrow-right'></i> Lambang Kab Halmahera Timur</a></div><div class='listing' id='text-menu'><a href='https://haltimkab.rahadian-consulting.com/artikel/data-geografi' target='_blank'><i class='fa fa-long-arrow-right'></i> Letak Geografis</a><br><br><a href='https://haltimkab.rahadian-consulting.com/artikel/kependudukan'target='_blank'><i class='fa fa-long-arrow-right'></i> Data Demografi</a></div><div class='listing' id='text-menu'><a href='https://haltimkab.rahadian-consulting.com/artikel/peta-halmahera-timur'target='_blank'><i class='fa fa-long-arrow-right'></i> Peta Halmahera Timur</a><br><br><a href='https://haltimkab.rahadian-consulting.com/artikel/halmahera-timur-temp-dulu' target='_blank'><i class='fa fa-long-arrow-right'></i> Halmahera Timur Tempo Dulu</a></div>";
			break;
			case "Pemerintahan":
				masukan = "<div class='listing'  id='text-menu'><a href='https://puprhaltim.rahadian-consulting.com/' target='_blank'><i class='fa fa-long-arrow-right'></i>Ketenaga Kerjaan</a></div><div class='listing'><a href='<?php echo base_url('struktur');?>'target='_blank'><i class='fa fa-long-arrow-right'></i>Struktur Pemerintahan</a></div>";
			break;
			case "Investasi":
				masukan = "<div class='listing'  id='text-menu'><a href='#'><i class='fa fa-long-arrow-right'></i>A</a><br><br><a href='#'><i class='fa fa-long-arrow-right'></i>A</a><br><br><a href='#'><i class='fa fa-long-arrow-right'></i>A</a></div><div class='listing'  id='text-menu'><a href='#'><i class='fa fa-long-arrow-right'></i>A</a><br><br><a href='#'><i class='fa fa-long-arrow-right'></i> A</a><br><br><a href='#'><i class='fa fa-long-arrow-right'></i>A</a></div><div class='listing'  id='text-menu'><a href='#'><i class='fa fa-long-arrow-right'></i>A</a><br><br><a href='#'><i class='fa fa-long-arrow-right'></i>A</a><br><br><a href='#'><i class='fa fa-long-arrow-right'></i>A</a></div><div class='listing'  id='text-menu'><a href='#'><i class='fa fa-long-arrow-right'></i> A</a><br><br><a href='#'><i class='fa fa-long-arrow-right'></i>A</a><br><br></div>";
			break;
			/*case "Transparansi":
				masukan = "<div class='listing'><a href='#'><i class='fa fa-long-arrow-right'></i> Ringkasan RKA SKPD</a><br><br><a href='#'><i class='fa fa-long-arrow-right'></i> Ringkasan RKA PPKD</a><br><br><a href='#'><i class='fa fa-long-arrow-right'></i> Perda Tentang APBD</a></div><div class='listing'><a href='#'><i class='fa fa-long-arrow-right'></i> Perwali Tentang APBD</a><br><br><a href='#'><i class='fa fa-long-arrow-right'></i> RAPERDA Tentang APBD</a><br><br><a href='#'><i lass='fa fa-long-arrow-right'></i> RAPERDA Tentang Perubahan APBD</a></div><div class='listing'><a href='#'><i class='fa fa-long-arrow-right'></i> Ringkasan DPA SKPD</a><br><br><a href='#'><i class='fa fa-long-arrow-right'></i> Ringkasan DPA PPKD</a><br><br><a href='#'><i class='fa fa-long-arrow-right'></i> LRA Seluruh SKPD</a></div><div class='listing'><a href='#'><i class='fa fa-long-arrow-right'></i> LRA PPKD</a><br><br><a href='#'><i class='fa fa-long-arrow-right'></i> LKPD Sudah Teraudit</a><br><br><a href='#'><i class='fa fa-long-arrow-right'></i> Laporan Keterbukaan Informasi Publik</a></div><div class='listing'><a href='#'><i class='fa fa-long-arrow-right'></i> PPID Kab Halmahera Timur</a><br><br><a href=#'><i class='fa fa-long-arrow-right'></i> Laporan Kinerja Instansi Pemerintah</a><br><br><a href='#'><i class='fa fa-long-arrow-right'></i> Indikator Kinerja Utama</a></div>";
			break;*/
			case "Sektor Unggulan":
				masukan = "<div class='listing'  id='text-menu'><a href='#'><i class='fa fa-long-arrow-right'></i>Pariwisata</a><br><br><a href='https://pertanianhaltim.rahadian-consulting.com/'target='_blank'><i class='fa fa-long-arrow-right'></i>Pertanian</a></div><div class='listing'  id='text-menu'> <a href='https://perikananhaltim.rahadian-consulting.com/'target='_blank'><i class='fa fa-long-arrow-right'></i>Perikanan</a><br><br><a href='<?php echo base_url('pertambangan');?>'target='_blank'><i class='fa fa-long-arrow-right'></i> Pertambangan</a></div>";
		break;
            case "Smart City":
                masukan = "<div class='listing'><a href='https://haltimkab.rahadian-consulting.com/blog/kategori/-Smart-Governance'target='_blank'><i class='fa fa-long-arrow-right'></i> Smart Governance</a><br><br><a href='https://haltimkab.rahadian-consulting.com/blog/kategori/Smart-Branding'target='_blank'><i class='fa fa-long-arrow-right'></i> Smart Branding</a><br><br></div><div class='listing'>	<a href='https://haltimkab.rahadian-consulting.com/blog/kategori/Smart-Ekonomi' target='_blank'><i class='fa fa-long-arrow-right'></i> Smart Ekonomi</a><br><br><a href='https://haltimkab.rahadian-consulting.com/blog/kategori/--Smart-Living'target='_blank'><i class='fa fa-long-arrow-right'></i> Smart Living</a></div><div class='listing'><a href='https://haltimkab.rahadian-consulting.com/blog/kategori/Smart-Society' target='_blank'><i class='fa fa-long-arrow-right'></i>Smart Society</a><br><br><a href='https://haltimkab.rahadian-consulting.com/blog/kategori/Smart-Environment' target='_blank'><i class='fa fa-long-arrow-right'></i> Smart Environment</a></div>";
            	break;	
			/*case "Pariwisata":
				masukan = "<div class='listing'><a href='#'><i class='fa fa-long-arrow-right'></i> Hotel</a><br><br><a href='#'><i class='fa fa-long-arrow-right'></i> Rumah Makan dan Restoran</a><br><br><a href='#'><i class='fa fa-long-arrow-right'></i> Tour dan Travel</a></div><div class='listing'><a href='#'><i class='fa fa-long-arrow-right'></i> Money Changer</a><br><br><a href='#'><i class='fa fa-long-arrow-right'></i> Pusat Perbelanjaan</a><br><br><a href='#'><i class='fa fa-long-arrow-right'></i> Tempat Rekreasi</a></div><div class='listing'><a href='#'><i class='fa fa-long-arrow-right'></i> Jajanan Oleh - Oleh</a><br><br><a href='#'><i class='fa fa-long-arrow-right'></i> Kerajinan dan Sovenir</a><br><br><a href='#'><i class='fa fa-long-arrow-right'></i> Destinasi Wisata</a></div>";
			break;*/
		}
		$(".gelembung_informasi#"+bagian).html(masukan);
	});
	$(".wrap_content_active").click(function(){
		$(this).parent().children(".wrap_content").slideToggle("slow","linear");
		$(this).toggle(250,"linear");
		$(".gelembung_informasi#bawah").slideUp("slow","linear");
		$(".gelembung_informasi#atas").slideUp("slow","linear");
		$(this).parent().children(".arrow-up").slideUp("slow","linear");
		$("body").css("overflow-y","scroll");
		$("body").css("overflow-x","hidden");
		$("body").css("background-size","100% 125%");
	});
	 var w = window,
		     d = document,
		     e = d.documentElement,
	  	     g = d.body,
		     x = w.innerWidth || e.clientWidth || g.clientWidth, // x = Lebar layar
		     y = w.innerHeight || e.clientHeight || g.clientHeight; // y = Tinggi layar

		// // Tampilkan lebar dan tinggi layar dalam kotak pesan
		 //alert('Lebar layar: ' + x + '; Tinggi layar: ' + y);
});
</script>
</body>
</html>