<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$base_url = load_class('Config')->config['base_url'];

<?php echo $base_url ?>
echo "\nERROR: ",
	$heading,
	"\n\n",
	$message,
	"\n\n";